import 'dotenv/config';
import express from 'express';
import nodemailer from 'nodemailer';
import { ImapFlow } from 'imapflow';
import crypto from 'node:crypto';

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static('public'));

const PORT = Number(process.env.PORT || 3000);
const POLL_MS = Number(process.env.POLL_SECONDS || 5) * 1000;
const TIMEOUT_MS = Number(process.env.TIMEOUT_SECONDS || 300) * 1000;

const boxes = [
  {
    id: 'box1',
    email: process.env.BOX1_EMAIL || 'michpres12@gmail.com',
    host: process.env.BOX1_IMAP_HOST,
    port: Number(process.env.BOX1_IMAP_PORT || 993),
    secure: String(process.env.BOX1_IMAP_SECURE || 'true') === 'true',
    user: process.env.BOX1_IMAP_USER,
    pass: process.env.BOX1_IMAP_PASS,
    sender: process.env.BOX1_EXPECTED_SENDER || ''
  },
  {
    id: 'box2',
    email: process.env.BOX2_EMAIL || 'haryjack986@gmail.com',
    host: process.env.BOX2_IMAP_HOST,
    port: Number(process.env.BOX2_IMAP_PORT || 993),
    secure: String(process.env.BOX2_IMAP_SECURE || 'true') === 'true',
    user: process.env.BOX2_IMAP_USER,
    pass: process.env.BOX2_IMAP_PASS,
    sender: process.env.BOX2_EXPECTED_SENDER || ''
  }
];

const tests = new Map();

const smtp = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: String(process.env.SMTP_SECURE || 'false') === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

function newId() {
  return crypto.randomBytes(8).toString('hex');
}

function configuredBox(box) {
  return Boolean(box.host && box.user && box.pass);
}

async function findMessage(client, folder, subject, expectedSender, sinceMs) {
  try {
    const lock = await client.getMailboxLock(folder);
    try {
      const sinceDate = new Date(sinceMs - 60 * 1000);
      const uids = await client.search({
        since: sinceDate,
        subject
      });

      if (!uids.length) return false;

      for await (const msg of client.fetch(uids.slice(-10), {
        uid: true,
        envelope: true,
        internalDate: true,
        source: true
      })) {
        const received = msg.internalDate ? new Date(msg.internalDate).getTime() : 0;
        if (received && received < sinceMs - 60 * 1000) continue;

        const envelopeFrom = (msg.envelope?.from || [])
          .map(x => x.address || '')
          .filter(Boolean)
          .join(',')
          .toLowerCase();

        const source = msg.source?.toString('utf8') || '';
        const fromHeader = (source.match(/^from:\s*(.+)$/im)?.[1] || '').toLowerCase();

        const senderOk = !expectedSender ||
          envelopeFrom.includes(expectedSender.toLowerCase()) ||
          fromHeader.includes(expectedSender.toLowerCase());

        const subjectOk = (msg.envelope?.subject || '').trim() === subject.trim() ||
          source.toLowerCase().includes(`subject: ${subject.trim().toLowerCase()}`);

        if (senderOk && subjectOk) {
          return true;
        }
      }
      return false;
    } finally {
      lock.release();
    }
  } catch {
    return false;
  }
}

async function locateTest(box, subject, sinceMs) {
  if (!configuredBox(box)) {
    return { status: 'not_configured', checkedAt: new Date().toISOString() };
  }

  const client = new ImapFlow({
    host: box.host,
    port: box.port,
    secure: box.secure,
    auth: { user: box.user, pass: box.pass },
    logger: false
  });

  try {
    await client.connect();
    const folders = await client.list();

    const inbox = folders.find(f => f.path.toUpperCase() === 'INBOX')?.path || 'INBOX';
    const junk =
      folders.find(f => f.specialUse === '\\Junk')?.path ||
      folders.find(f => /spam|junk/i.test(f.path))?.path;

    if (await findMessage(client, inbox, subject, box.sender, sinceMs)) {
      return { status: 'inbox', folder: inbox, checkedAt: new Date().toISOString() };
    }

    if (junk && await findMessage(client, junk, subject, box.sender, sinceMs)) {
      return { status: 'spam', folder: junk, checkedAt: new Date().toISOString() };
    }

    return { status: 'waiting', checkedAt: new Date().toISOString() };
  } catch (err) {
    return {
      status: 'error',
      error: err.message,
      checkedAt: new Date().toISOString()
    };
  } finally {
    try { await client.logout(); } catch {}
  }
}

async function watchBox(test, index, sinceMs) {
  const box = boxes[index];
  const started = Date.now();

  while (Date.now() - started < TIMEOUT_MS) {
    const result = await locateTest(box, test.subject, sinceMs);
    test.results[index] = {
      ...test.results[index],
      ...result
    };

    if (result.status === 'inbox' || result.status === 'spam') return;

    await new Promise(r => setTimeout(r, POLL_MS));
  }

  test.results[index].status = 'not_received';
  test.results[index].checkedAt = new Date().toISOString();
}

app.get('/api/mailboxes', (_req, res) => {
  res.json(boxes.map(b => ({ id: b.id, email: b.email, configured: configuredBox(b) })));
});

app.post('/api/test', async (req, res) => {
  const { subject, html } = req.body || {};

  if (!subject?.trim()) {
    return res.status(400).json({ error: 'Subject is required.' });
  }
  if (!html?.trim()) {
    return res.status(400).json({ error: 'HTML is required.' });
  }

  const id = newId();

  const test = {
    id,
    subject: subject.trim(),
    createdAt: new Date().toISOString(),
    results: boxes.map(b => ({
      mailbox: b.email,
      status: configuredBox(b) ? 'sending' : 'not_configured'
    }))
  };

  tests.set(id, test);

  try {
    for (let i = 0; i < boxes.length; i++) {
      const box = boxes[i];
      if (!box.email || !configuredBox(box)) continue;

      test.results[i].status = 'sent';

      await smtp.sendMail({
        from: `${process.env.FROM_NAME || 'Inbox Tester'} <${process.env.FROM_EMAIL || process.env.SMTP_USER}>`,
        to: box.email,
        subject: subject.trim(),
        html,
        headers: {
          'X-Inbox-Test-ID': id,
          'X-Inbox-Tester': 'v1'
        }
      });

      // Track only messages received around this test's send time.
      const sentAt = Date.now();
      test.results[i].sentAt = new Date(sentAt).toISOString();

      // Each mailbox is monitored independently for the next 5 minutes.
      watchBox(test, i, sentAt).catch(err => {
        test.results[i] = {
          ...test.results[i],
          status: 'error',
          error: err.message
        };
      });
    }

    res.json(test);
  } catch (err) {
    test.results = test.results.map(r =>
      r.status === 'sent' ? { ...r, status: 'send_error', error: err.message } : r
    );
    res.status(500).json(test);
  }
});

app.get('/api/test/:id', (req, res) => {
  const test = tests.get(req.params.id);
  if (!test) return res.status(404).json({ error: 'Test not found.' });
  res.json(test);
});

app.listen(PORT, () => {
  console.log(`Inbox Tester running at http://localhost:${PORT}`);
});
